from PIL import Image
import argparse
import os
import re

# Reversible character mapping (excluding < and > for XML)
char_map = {
    ':': '_colon_', '*': '_star_', '|': '_pipe_', '?': '_qmark_',
    '/': '_slash_', '\\': '_bslash_', '"': '_quote_'
}
reverse_map = {v: k for k, v in char_map.items()}

filename_safe_map = {
    '<': '_lt_', '>': '_gt_', ':': '_colon_', '*': '_star_',
    '|': '_pipe_', '?': '_qmark_', '/': '_slash_', '\\': '_bslash_', '"': '_quote_'
}
reverse_filename_safe_map = {v: k for k, v in filename_safe_map.items()}

def sanitize_filename(name):
    for char, token in char_map.items():
        name = name.replace(char, token)
    return name.strip()

def unsanitize_filename(name):
    combined_map = {**reverse_map, **reverse_filename_safe_map}
    for token, char in combined_map.items():
        name = name.replace(token, char)
    return name.strip()

def safe_filename(name):
    for char, token in filename_safe_map.items():
        name = name.replace(char, token)
    return name.strip()

# Uniform frame data for Alphabet letters
UNIFORM_FRAME_WIDTH = 36
UNIFORM_FRAME_HEIGHT = 36
UNIFORM_FRAME_Y = -1
UNIFORM_FRAME_X = 0

# Safe separator for filenames
separator = "__"

# Argument parser
parser = argparse.ArgumentParser(description="Extract or rebuild texture atlas with optional frame normalization.")
parser.add_argument("name", help="Base name of PNG and XML files (e.g. alphabet)")
parser.add_argument("file_base_name", nargs="?", help="Optional prefix for saved images")
parser.add_argument("--rebuild", action="store_true", help="Rebuild XML and spritesheet from extracted frames")
parser.add_argument("--normalize", action="store_true", help="Force uniform frame data for Alphabet letters")

args = parser.parse_args()

frames_dir = "individual-frames"
rebuilt_dir = "rebuilt"
os.makedirs(frames_dir, exist_ok=True)
os.makedirs(rebuilt_dir, exist_ok=True)

if not args.rebuild:
    # Extraction mode
    imagepath = f"{args.name}.png"
    xmlpath = f"{args.name}.xml"

    if not os.path.exists(imagepath) or not os.path.exists(xmlpath):
        print(f"❌ Missing file: {imagepath if not os.path.exists(imagepath) else xmlpath}")
        exit(1)

    # Load and fix malformed XML
    with open(xmlpath, "r", encoding="utf-8") as f:
        xml_text = f.read()
    xml_text = xml_text.replace('name="<', 'name="&lt;')
    xml_text = xml_text.replace('name=">', 'name="&gt;')

    try:
        from lxml import etree
        xml_tree = etree.fromstring(xml_text.encode("utf-8"), etree.XMLParser(recover=True))
        im = Image.open(imagepath)
    except Exception as e:
        print(f"❌ Failed to load assets: {e}")
        exit(1)

    for i, obj in enumerate(xml_tree.findall(".//SubTexture")):
        try:
            x1 = int(obj.get('x', 0))
            y1 = int(obj.get('y', 0))
            w = int(obj.get('width', 1))
            h = int(obj.get('height', 1))

            raw_name = obj.get('name')
            if not raw_name or raw_name.strip() == "":
                raw_name = f"unnamed_{i}"

            raw_name = raw_name.replace("&lt;", "<").replace("&gt;", ">")

            print(f"🔍 Extracting raw name: {raw_name}")
            safe_name = safe_filename(raw_name)
            print(f"📦 Safe filename: {safe_name}")

            fx = obj.get('frameX')
            fy = obj.get('frameY')
            fw = obj.get('frameWidth')
            fh = obj.get('frameHeight')

            frame_suffix = ""
            if all(v is not None for v in [fx, fy, fw, fh]):
                frame_suffix = f"{separator}frameX_{fx}{separator}frameY_{fy}{separator}frameWidth_{fw}{separator}frameHeight_{fh}"

            im1 = im.crop((x1, y1, x1 + w, y1 + h))
            save_name = f"{args.file_base_name or args.name}{separator}{safe_name}{separator}{x1}{separator}{y1}{separator}{w}{separator}{h}{frame_suffix}.png"
            im1.save(os.path.join(frames_dir, save_name))
            print(f"✅ Saved: {save_name}")
        except Exception as e:
            print(f"⚠️ Failed to extract sprite {i}: {e}")
else:
    # Rebuild mode
    output_xml = os.path.join(rebuilt_dir, f"{args.name}.xml")
    output_sheet = os.path.join(rebuilt_dir, f"{args.name}.png")

    frame_data = []
    max_sheet_width = 2048
    sheet_height = 0

    for filename in sorted(os.listdir(frames_dir)):
        if filename.endswith(".png"):
            try:
                print(f"🧪 Parsing: {filename}")
                parts = filename[:-4].split(separator)

                coord_start = None
                for i, part in enumerate(parts):
                    try:
                        int(part)
                        coord_start = i
                        break
                    except ValueError:
                        continue

                if coord_start is None or len(parts) < coord_start + 4:
                    print(f"⚠️ Skipped malformed filename: {filename}")
                    continue

                original_name = unsanitize_filename(separator.join(parts[1:coord_start]))
                print(f"🔁 Unsanitized name: {original_name}")

                w = int(parts[coord_start + 2])
                h = int(parts[coord_start + 3])

                fx = fy = fw = fh = None
                for part in parts[coord_start + 4:]:
                    if part.startswith("frameX_"): fx = int(part[7:])
                    elif part.startswith("frameY_"): fy = int(part[7:])
                    elif part.startswith("frameWidth_"): fw = int(part[11:])
                    elif part.startswith("frameHeight_"): fh = int(part[12:])

                if args.normalize and len(original_name) == 1 and original_name.isalpha():
                    fx, fy, fw, fh = UNIFORM_FRAME_X, UNIFORM_FRAME_Y, UNIFORM_FRAME_WIDTH, UNIFORM_FRAME_HEIGHT

                frame_data.append((filename, original_name, w, h, fx, fy, fw, fh))
            except Exception as e:
                print(f"⚠️ Failed to parse {filename}: {e}")

    x_cursor = 0
    y_cursor = 0
    row_height = 0
    layout = []

    for _, _, w, h, *_ in frame_data:
        if x_cursor + w > max_sheet_width:
            x_cursor = 0
            y_cursor += row_height
            row_height = 0
        layout.append((x_cursor, y_cursor))
        x_cursor += w
        row_height = max(row_height, h)
    sheet_height = y_cursor + row_height

    sheet = Image.new("RGBA", (max_sheet_width, sheet_height), (0, 0, 0, 0))

    xml_lines = []
    xml_lines.append('<?xml version="1.0" encoding="utf-8"?>')
    xml_lines.append(f'<TextureAtlas imagePath="{args.name}.png">')
    xml_lines.append('<!-- Created with Adobe Animate version 21.0.6.41649 -->')
    xml_lines.append('<!-- http://www.adobe.com/products/animate.html -->')

    for (filename, original_name, w, h, fx, fy, fw, fh), (x, y) in zip(frame_data, layout):
        try:
            img = Image.open(os.path.join(frames_dir, filename)).convert("RGBA")
            sheet.paste(img, (x, y))

            fx = 0 if fx is None else max(fx, -w)
            fy = 0 if fy is None else max(fy, -h)
            fw = w if fw is None else fw
            fh = h if fh is None else fh

            xml_lines.append(
                f'  <SubTexture name="{original_name}" x="{x}" y="{y}" width="{w}" height="{h}" '
                f'frameX="{fx}" frameY="{fy}" frameWidth="{fw}" frameHeight="{fh}"/>'
            )

            print(f"🧩 Added to XML: {original_name}")
        except Exception as e:
            print(f"⚠️ Failed to paste {filename}: {e}")

    xml_lines.append('</TextureAtlas>')

    sheet.save(output_sheet)

    with open(output_xml, "w", encoding="utf-8") as f:
        f.write("\n".join(xml_lines))

    print(f"✅ Rebuilt XML: {output_xml}")
    print(f"✅ Rebuilt spritesheet: {output_sheet}")
